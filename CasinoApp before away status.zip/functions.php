<?php

require_once 'variables/dbconnectionvariables.php';

//****************************************************************************************

function setmessage($message, $receiversid, $handlerid, $messagetype = 3) {
    $dbc = mysqli_connect(host, user, password, database)
            or die("Error connecting database");

    $query = "insert into messages(message, message_type, user_id, handler_id) values ('$message', $messagetype, $receiversid, $handlerid)";
    mysqli_query($dbc, $query);
    if (mysqli_affected_rows($dbc) == 1) {
        mysqli_close($dbc);
        return TRUE;
    } else {
        mysqli_close($dbc);
        return FALSE;
    }
}

//****************************************************************************************
//
//****************************************************************************************
function setchips($userid, $chips) {
    $dbc = mysqli_connect(host, user, password, database)
            or die("Error connecting database");

    $query = "update user_cash set chips = $chips where user_id = $userid";
    mysqli_query($dbc, $query);

    if (mysqli_affected_rows($dbc) == 1) {
        mysqli_close($dbc);
        return TRUE;
    } else {
        mysqli_close($dbc);
        return FALSE;
    }
}

// **************************************************************************************
// 
// ***********************************************************************************
function getchips($userid) {
    $dbc = mysqli_connect(host, user, password, database)
            or die("Error connecting database");

    $noofchips = NULL;

    $query = "select chips from user_cash where user_id = $userid";
    $result = mysqli_query($dbc, $query);
    if (mysqli_num_rows($result) != 0) {
        while ($row = mysqli_fetch_array($result)) {
            $noofchips = $row[0];
        }
    }
    mysqli_close($dbc);
    return $noofchips;
}

// ****************************************************************************************
// 
//
//****************************************************************************************
function fetchdevicetoken($messageto) {

    $dbc2 = mysqli_connect(host, user, password, database)
            or die("Error connecting database");

    $query6 = "select status, device_token from current_login_status where user_id = $messageto";
    $result6 = mysqli_query($dbc2, $query6);

    $receiverisonline = FALSE;
    $devicetokenofreceiver = NULL;

    if (mysqli_num_rows($result6) != 0) {
        while ($row6 = mysqli_fetch_array($result6)) {
            if ($row6[0] == 1) {
                $receiverisonline = TRUE;
                $devicetokenofreceiver = $row6[1];
                break;
            }
        }
    }

    // if receiveer is online, get current device token, otherwise main device token

    if (is_null($devicetokenofreceiver)) {

        $query7 = "select devicetoken from user_details where user_id = $messageto";
        $result7 = mysqli_query($dbc2, $query7);
        if (mysqli_num_rows($result7) != 0) {
            while ($row7 = mysqli_fetch_array($result7)) {
                $devicetokenofreceiver = $row7[0];
            }
        }
    }
    mysqli_close($dbc2);
    return $devicetokenofreceiver;
}

////****************************************************************************************
//
//
//--------------------------------------------------------------------------------------
//
//****************************************************************************************
function fetchgametype($sessionid) {
    $dbc = mysqli_connect(host, user, password, database)
            or die("Error connecting database");

    $query = "select game_type from table_gamesessions where session_id = " . $sessionid;

    $result = mysqli_query($dbc, $query);

    $gametype = "";
    if (mysqli_num_rows($result) == 1) {
        while ($row = mysqli_fetch_array($result)) {
            $gametype = $row[0];
        }
    }
    mysqli_close($dbc);

    return $gametype;
}

//********************************************************************************
//
//****************************************************************************************
function fetchname($messagefrom) {
    $dbc3 = mysqli_connect(host, user, password, database)
            or die("Error connecting database");

    $query5 = "select name from user_details where user_id = $messagefrom";
    $result5 = mysqli_query($dbc3, $query5);
    $nameinpush = NULL;
    if (mysqli_num_rows($result5) == 1) {
        while ($row5 = mysqli_fetch_array($result5)) {
            $nameinpush = $row5[0];
        }
    } else {
        $nameinpush = "A friend : ";
    }
    mysqli_close($dbc3);
    return $nameinpush;
}

//****************************************************************************************
//
//
//****************************************************************************************
function setlatestmessage($sessionid, $userid, $message, $status = 0) {
    $dbc = mysqli_connect(host, user, password, database)
            or die("Error connecting database");

    // there was no row, so just add a row
    $query2 = "insert into game_messages(session_id, user_id, message, status) values ( $sessionid, $userid, '$message', $status)";
    mysqli_query($dbc, $query2);

    // if a row was affected, close connection and send true
    if (mysqli_affected_rows($dbc) == 1) {
        mysqli_close($dbc);
        return TRUE;
    }
    mysqli_close($dbc);
    return FALSE;
}

//
//****************************************************************************************
//
//****************************************************************************************

function increasedecreasechips($userid, $chips, $status) {
    $dbc = mysqli_connect(host, user, password, database)
            or die("Error connecting database");

    // fetch no of chips of this user
    $alreadyhavechips = getchips($userid);

    // check if we have got the chips
    if (is_null($alreadyhavechips)) {
        mysqli_close($dbc);
        return FALSE;
    } else {
        // get new chips count
        if ($status == 1) {
            $newchipscount = $alreadyhavechips + $chips;
        } else {
            $newchipscount = $alreadyhavechips - $chips;
        }
        // set this as the no of chips of this user
        $done = setchips($userid, $newchipscount);

        // check if it is done successfully
        if ($done) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
    mysqli_close($dbc);
}

//
//****************************************************************************************
//
//****************************************************************************************

function format_cash($cash) {

    // strip any commas 
    $cash = (0 + STR_REPLACE(',', '', $cash));

    // make sure it's a number...
    IF (!IS_NUMERIC($cash)) {
        RETURN FALSE;
    }

    // filter and format it 
    IF ($cash > 1000000000000) {
        RETURN ROUND(($cash / 1000000000000), 1) . ' T';
    } ELSEIF ($cash > 1000000000) {
        RETURN ROUND(($cash / 1000000000), 1) . ' B';
    } ELSEIF ($cash > 1000000) {
        RETURN ROUND(($cash / 1000000), 1) . ' M';
    } ELSEIF ($cash > 1000) {
        RETURN ROUND(($cash / 1000), 1) . ' K';
    }

    RETURN NUMBER_FORMAT($cash);
}

//****************************************************************************************
function setlatestmessageid($sessionid, $userid, $message, $status = 0) {
    $dbc = mysqli_connect(host, user, password, database)
            or die("Error connecting database");

    // there was no row, so just add a row
    $query2 = "insert into game_messages(session_id, user_id, message, status) values ( $sessionid, $userid, '$message', $status)";
    mysqli_query($dbc, $query2);

    // if a row was affected, close connection and send true
    if (mysqli_affected_rows($dbc) == 1) {
        $id = mysqli_insert_id($dbc);
        mysqli_close($dbc);
        return $id;
    }
    mysqli_close($dbc);
    return FALSE;
}

?>
