<?php

header('Content-Type:text/xml');
echo '<?xml version="1.0" encoding="utf-8"?>';
require_once 'variables/dbconnectionvariables.php';

// check if requiredd fields were passed in url
if (!isset($_GET['session_id']) || !isset($_GET['user_id'])) {
    echo 'session_id was not passed';
} else {
    // grab the variable
    $sessionid = $_GET['session_id'];
    $userid = $_GET['user_id'];

    //sanity check the variable
    if (!is_numeric($sessionid)) {
        echo 'There is unexpected error';
    } else {

        // fetch all session ids playing gme in this session id
        $dbc = mysqli_connect(host, user, password, database)
                or die("Error connecting database");

        echo '<users>';

        $query2 = "select table_type from table_gamesessions where session_id = $sessionid";
        $result2 = mysqli_query($dbc, $query2);

        if (mysqli_num_rows($result2) != 0) {
            while ($row2 = mysqli_fetch_array($result2)) {
                echo '<table_type>';
                echo $row2[0];
                echo '</table_type>';
            }
            $query3 = "select wins from games_players where user_id = $userid and session_id = $sessionid";
            $result3 = mysqli_query($dbc, $query3);
            if (mysqli_num_rows($result3) > 0) {
                $winnings = mysqli_fetch_row($result3);

                echo '<winnings>';
                echo $winnings[0];
                echo '</winnings>';
            }

            $query = "select user_details.user_id,games_players.status,invitations.status, name, gold, chips, icon_name
            from user_details left join user_cash on user_details.user_id = user_cash.user_id 
            left join user_icon on user_details.user_id = user_icon.user_id 
            left join games_players on user_details.user_id = games_players.user_id and games_players.session_id = $sessionid
            left join invitations on user_details.user_id = invitations.invitation_to and invitations.session_id = $sessionid
            
            having user_details.user_id in 
            (SELECT user_id
            FROM games_players where session_id = $sessionid
            union   
            select invitation_to from invitations 
            where session_id = $sessionid)
            order by invitations.datetime, games_players.datetime  
            ";

            $result = mysqli_query($dbc, $query);



            if (mysqli_num_rows($result) != 0) {
                while ($row = mysqli_fetch_array($result)) {
                    echo '<user>';

                    echo '<user_id>';
                    echo $row[0];
                    echo '</user_id>';

                    if (is_null($row[1]) && !is_null($row[2])) {
                        // it means just an invitation is sent to this user
                        echo '<status>';
                        echo '1';
                        echo '</status>';
                    } elseif (!is_null($row[1]) && is_null($row[2])) {
                        // it means this user is playing the game
                        // now if $row[1] is zero, the player is playing game, and is active

                        if ($row[1] == 0) {
                            echo '<status>';
                            echo '2';
                            echo '</status>';
                        } elseif ($row[1] == 1) {
                            echo '<status>';
                            echo '3';
                            echo '</status>';
                        }
                    }
                    echo '<name>';
                    echo $row['name'];
                    echo '</name>';

                    // fetch latest message of this player
                    $query3 = "select message, status, id from game_messages where session_id = $sessionid and user_id= $row[0] order by datetime desc limit 1";
                    $result3 = mysqli_query($dbc, $query3);

                    $printmessage = NULL;
                    $printmessagetype = NULL;
                    $handlerid = NULL;

                    if (mysqli_num_rows($result3) > 0) {
                        while ($row3 = mysqli_fetch_array($result3)) {
                            $printmessage = $row3['message'];
                            $printmessagetype = $row3[1];
                            $handlerid = $row3['id'];
                        }
                    }
                    echo '<message_type>';
                    echo $printmessagetype;
                    echo '</message_type>';

                    echo '<message>';
                    echo $printmessage;
                    echo '</message>';

                    echo '<gold>';
                    echo $row['gold'];
                    echo '</gold>';

                    echo '<chips>';
                    echo $row['chips'];
                    echo '</chips>';

                    echo '<icon_name>';
                    echo $row['icon_name'];
                    echo '</icon_name>';

                    echo '</user>';

                    // delete a row from message table now
                    $query4 = "delete from messages where handler_id = $handlerid and message_type=3 and user_id = $userid";
                    mysqli_query($dbc, $query4);
                }
            }
        }
        echo '</users>';
        mysqli_close($dbc);
    }
}
?>