<?php

require_once 'variables/dbconnectionvariables.php';

$dbc = mysqli_connect(host, user, password, database)
        or die("Error connecing database");

/* select all fields from the database */
$query = "select * from user_cash";
$result = mysqli_query($dbc, $query);
$numrows = mysqli_num_rows($result);

/* if there are some rows */
if ($numrows > 0) {
    while ($row = mysqli_fetch_array($result)) {
        $time1 = $row['datetime'];
        $time = strtotime($time1);

        $timezone = "Asia/Calcutta";
        if (function_exists('date_default_timezone_set'))
            date_default_timezone_set($timezone);

        $timenow = time();

        // if the difference is more than 10 mins => later change it to 24 hours 
        if (($timenow - $time) > 60 * 60) {

            // get userid of this user from earlier query.
            $userid = $row['user_id'];

            // get older chips available to this user
            $olderchips = $row['chips'];
            $status = $row['status'];
            // get the job of this user
            $jobname = "";
            $query2 = "select job_name from user_job where user_id = $userid";
            $result2 = mysqli_query($dbc, $query2);
            if (mysqli_num_rows($result2) != 0) {
                while ($row2 = mysqli_fetch_array($result2)) {
                    $jobname = $row2['job_name'];
                }
            } else {
                die("Could not find any job for this user");
            }

            $chips = 0;
            if ($jobname == "Average Joe") {
                $chips = 500;
            } else if ($jobname == "Business Executive") {
                $chips = 2500;
            } else if ($jobname == "Poker Pro") {
                $chips = 20000;
            } else if ($jobname == "Rockstar") {
                $chips = 100000;
            }

            // update the chips available to the user
            //  $newchipscount = $olderchips + $chips;
            // $query3 = "update user_cash set chips = $newchipscount where user_id = $userid";
            //mysqli_query($dbc, $query3);
            // fetch active devicetoken of this user
            $query4 = "select status, device_token from current_login_status where user_id = $userid";
            $result4 = mysqli_query($dbc, $query4);

            $receiverisonline = FALSE;
            $devicetokenofreceiver = NULL;

            if (mysqli_num_rows($result4) != 0) {
                while ($row4 = mysqli_fetch_array($result4)) {
                    if ($row4[0] == 1) {
                        $receiverisonline = TRUE;
                        $devicetokenofreceiver = $row4[1];
                        break;
                    }
                }
            }

            // if receiveer is online, get current device token, otherwise main device token

            if (is_null($devicetokenofreceiver)) {
                $query5 = "select devicetoken from user_details where user_id = $userid";
                $result5 = mysqli_query($dbc, $query5);
                if (mysqli_num_rows($result5) != 0) {
                    while ($row5 = mysqli_fetch_array($result5)) {
                        $devicetokenofreceiver = $row5[0];
                    }
                }
            }

            // send a push to these users if status is 1
            if ($status == 1)
                sendpush($devicetokenofreceiver, $chips);
        } else {
            
        }
    }
}
mysqli_close($dbc);

function sendpush($devicetokenofreceiver, $noofchips) {

// Put your device token here (without spaces):
    $deviceToken = 'ddc158444fd422ddf04138ca6ada3f6a3eba0f3ac5b9b730a4b21befc7e136e3';

// Actual $deviceToken = $devicetokenofthereceiver;
// Put your private key's passphrase here:
    $passphrase = 'abcd';

// Put your alert message here:
    $message = 'You have received ' . $noofchips . ' chips';

////////////////////////////////////////////////////////////////////////////////

    $ctx = stream_context_create();
    stream_context_set_option($ctx, 'ssl', 'local_cert', 'hotel.pem');
    stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

// Open a connection to the APNS server
    $fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);

    if (!$fp)
        exit("Failed to connect: $err $errstr" . PHP_EOL);


// Create the payload body
    $body['aps'] = array(
        'alert' => $message,
        'sound' => '3'
    );

// Encode the payload as JSON
    $payload = json_encode($body);

// Build the binary notification
    $msg = chr(0) . pack('n', 32) . pack('H*', $devicetokenofreceiver) . pack('n', strlen($payload)) . $payload;

// Send it to the server
    $result = fwrite($fp, $msg, strlen($msg));

// Close the connection to the server
    fclose($fp);
}

?>